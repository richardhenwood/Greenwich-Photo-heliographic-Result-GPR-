package spotTools;
use pmeph;
use strict;
use warnings;
use Data::Dumper;
use Math::Trig;

# this package is a library of tools to be used on sunspots

# create an empemerisis - this will come in handy throughout!
my $ephmis = new pmeph;

sub calculateLBP {
    my $self = shift;
    my $spot = shift;
    my ($L_, $B_, $P_, $C_, $S_) = $ephmis->calc_LBP(
        $spot->getYear(),
        $spot->getMonth(),
        $spot->getDayOfMonth(),
        $spot->getHour());
    $spot->putSun_L0($L_);
    $spot->putSun_B0($B_);
    $spot->putSun_P($P_);
    $spot->putSun_S($S_);
    #print "spot is spot = " . $spot->is_spot();
    return $spot;
}

# ROUTINE TO CALCULATE THE LAT, LONG OF SPOTS uses radius and position angle, not x,y
sub calculate_heliographic {
    my $self = shift;
	my $spot = shift;
    #print $spot->raw_string;
    my $roe = deg2rad(&calculate_roe($self, $spot));
    my $sunB0 = deg2rad($spot->getSun_B0);
    my $ki = deg2rad($spot->getPositionAngle);
    my $phi = cos($roe)*sin($sunB0) +
        sin($roe)*cos($sunB0)*cos($ki);   
    $phi = asin($phi);
    my $lamda = sin($ki)*sin($roe)*sec($phi);
    $lamda = -1 * asin($lamda);
    $spot->putCalculatedLatitude(rad2deg($phi));
    $spot->putCalculatedLongitude(rad2deg($lamda));
    $spot->putCalculatedCarringtonLongitude(rad2deg($lamda)+$spot->getSun_L0);
    return $spot;
}

# returns a value of roe for a given spot.
# roe is returned in degrees.
sub calculate_roe {
    my $self = shift;
    my $spot = shift;
    my $sunS = deg2rad($spot->getSun_S() / 60);
    my $r_over_R = $spot->getSolarRadii;
    my $roe_dash = $r_over_R * $sunS;
    my $roe = asin($r_over_R) - $roe_dash;
    return rad2deg($roe);
}

sub calculateProjectedArea {
    my $self = shift;
    my $spot = shift;
    my $roe = deg2rad(&calculate_roe($self, $spot));
    my $area = $spot->getCorrectedUmbralArea();
#    print "area = '$area' roe = '$roe'\n";
    $spot->putCalculatedProjectedUmbralArea(2 * $area * cos($roe));
    $area = $spot->getCorrectedWholeSpotArea();
    $spot->putCalculatedProjectedWholeSpot(2 * $area * cos($roe));
}
sub calculateProjectedAreaFaculae {
    my $self = shift;
    my $spot = shift;
    my $roe = deg2rad(&calculate_roe($self, $spot));
    my $area = $spot->getFaculaeArea();
#    print "area = '$area' roe = '$roe'\n";
    $spot->putCalculatedProjectedFaculaeArea(2 * $area * cos($roe));
}

sub calculate_projected_wholespot {
    my $self = shift;
    my $spot = shift;
    
}

# calculate the helioprojective position of a spot from the 
# heliographic position.
=begin comment
sub calculate_helioprojective {
    my $self = shift;
	my $spot = shift;
	my $SunB0 = deg2rad($spot->getSun_B0);
	my $SunL0 = deg2rad($spot->getSun_L0);
	my $Sun_P = deg2rad($spot->getSun_P);
    my $ki = deg2rad($spot->getPositionAngle);
#	my $SunB0 = deg2rad(-3.1);#deg2rad($spot{Sun_B0});
#	my $SunL0 = 24.7;#deg2rad($spot{Sun_L0});
#	my $Sun_P = deg2rad($spot{Sun_P});
#    my $ki = deg2rad(43.6);#deg2rad($spot{Polar_angle_in_deg});

    # my $day_of_year = (( $spot{month} - 1 ) * 12)+ $spot{day_of_month} - 1;
    # above is simply wrong. below is a better way to calculate day of year.
    my $day_of_year = Day_of_Year($spot->getYear, $spot->getMonth, $spot->getDayOfMonth);
	my $SunSemiDiameter = deg2rad(&SunSemiDiameter($day_of_year) / 60);
# forward calculation
    my ($phi, $lamda, $roe);
    if (1){ 
        my $roe_dash = $spot{Distance_from_centre_of_solar_disc_in_solar_radii} * $SunSemiDiameter;
        my $roe = asin($spot{Distance_from_centre_of_solar_disc_in_solar_radii}) - $roe_dash;
        my $phi = cos($roe)*sin($SunB0) + sin($roe)*cos($SunB0)*cos($ki);
        $phi = asin($phi);
        my $lamda = sin($ki)*sin($roe)*sec($phi);
        $lamda = -1 * asin($lamda);

        print $spot{year} . "-".trim($spot{month})."-".trim($spot{day_of_month}). " " .$spot{Greenwich_sunspot_group_number} . " " .  &sf4(rad2deg($phi)) . " " . $spot{Latitude} . " " . &sf4(rad2deg($lamda)) . " " . $spot{Central_meridian_distance} . " " . cos($roe) ;
    }
        
    $lamda = deg2rad($spot{Central_meridian_distance});
    $phi = deg2rad($spot{Latitude});
    
#    print " $SunB0 ";
# print " " . cos($roe);
    #   print " " . rad2deg($roe);
    

# richard henwood soln.
    if (0) {
        my $cos_roe;
        my $sqrt_bit = 4 *( (sin($SunB0)**2/cos($SunB0))*(1-sin($lamda)**2*cos($phi)**2) - sin($lamda)**2*cos($phi)**2 - sin($phi)**2/cos($SunB0) + 1 ) ;
        $sqrt_bit = (cos($SunB0)/2) * sqrt($sqrt_bit);
        $cos_roe = sin($phi) * sin($SunB0) + $sqrt_bit;

        print " " . rad2deg($roe) ;
# for some reason rad2deg dosen't work, so i do a 'manual' conversion.
        #print " " . rad2deg(acos($cos_roe));
        print " " . 90 * acos($cos_roe)/(pi/2);

# this gets the -ve route - which looks wrong.
#        $cos_roe = sin($phi) * sin($SunB0) - $sqrt_bit;

#        print " " . rad2deg($roe) ;
# for some reason rad2deg dosen't work, so i do a 'manual' conversion.
        #print " " . rad2deg(acos($cos_roe));
#        print " " . 90 * acos($cos_roe)/(pi/2);
    }

    my ($A_, $B_, $C_);
# richard henwood soln' 2.
    if (1) {
        my $cos_roe_plus;
        $A_ = sin($SunB0)**2;
        $B_ = -2 * sin($phi) * sin($SunB0);
        $C_ = sin($phi)**2 - cos($SunB0)**2*(1 - cos($phi)**2*sin($lamda)**2);
        print " $A_ $B_ $C_ ";
        $cos_roe_plus = -$B_/(2*$A_) + sqrt( $B_**2 - 4*$A_*$C_)/(2*$A_);
        print " roe = " . $cos_roe_plus;
    }
    
# willis soln.
    my $willis_sin_roe;
    if (0) {
        my $sin_ki_plus;
        $A_ = (sin($phi)**2 - sin($SunB0)**2 - sin($lamda)**2*cos($phi)**2*cos($SunB0)**2)**2; 
        $A_ = $A_ + 4*sin($lamda)**2*sin($phi)**2*cos($phi)**2*cos($SunB0)**2;
        $B_ = 2*sin($lamda)**2*cos($phi)**2*((sin($phi)**2-sin($SunB0)**2-sin($lamda)**2*cos($phi)**2*cos($SunB0)**2) - 2*sin($phi)**2*cos($SunB0)**2);
        $C_ = sin($lamda)**4*cos($phi)**4;
        $sin_ki_plus = -$B_/(2*$A_) + sqrt( $B_**2 - 4*$A_*$C_)/(2*$A_);
        #  print " $A_ $B_ $C_ ";
        print " " . sqrt($sin_ki_plus);
        # $willis_sin_roe = (sin($lamda)*cos($phi))/sqrt($sin_ki_plus);
        # print " " . 90 * asin($willis_sin_roe)/(pi/2);
    }
    #  print " " . &sf4($roe) . " " . &sf4(rad2deg(acos($cos_roe)));# . " " . rad2deg(asin($willis_sin_roe)); 
    print " $day_of_year "; 
    print "\n";
}

sub sf4 { 
    my $n = shift;
    return floor($n*100)/100;
}
=cut comment

sub new { return bless{};}

1;
